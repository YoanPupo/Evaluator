/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MathRunner;

import evaluator.PostEval;
import java.awt.*;
import java.util.*;

/**
 *
 * @author CARLOS
 */
public class pencil {
   
    LinkedList<point> points;
    double x, y;
    boolean paint;
    double zoomLevel;
   

    public boolean isPaint() {
        return paint;
    }

    public double getZoomLevel() {
        return zoomLevel;
    }

    public void setZoomLevel(double zoomLevel) {
        this.zoomLevel = zoomLevel;
    }

    public void setPaint(boolean paint) {
        this.paint = paint;
        points.add(new point(x, y, paint));
    }

    public pencil() {
        points = new LinkedList<point>();

    }

    public void moveTo(double x, double y, boolean paint) {
        this.x = x;
        this.y = y;

        points.add(new point(x, y, paint));

    }
     public void moveTo(point p) {
       

        points.add(p);

    }
    public void moveIn(double x, double y) {
        this.x += x;
        this.y += y;
        if (paint) {
            points.add(new point(x, y, paint));
        }

    }

    public void up(int y) {

        this.y += y;
        if (paint) {
            points.add(new point(x, y, paint));
        }

    }

    public void down(int y) {

        this.y -= y;
        if (paint) {
            points.add(new point(x, y, paint));
        }

    }

    public void right(int x) {

        this.x += x;
        if (paint) {
            points.add(new point(x, y, paint));
        }

    }

    public void left(int x) {

        this.x -= x;
        if (paint) {
            points.add(new point(x, y, paint));
        }

    }
    
    public void draw(Graphics gc) {
        if (points.isEmpty()) {
            return;
        }
        point prev, get = points.get(0);
        prev = get;
        boolean wait=false;
        for (point p : points) {

            get = new point(p);
          
            get.translate(get.getX() * zoomLevel, get.getY() * zoomLevel);
            if (!wait&&p.getY() != PostEval.INVALID_VALUE) {

                prev.drawLine(gc, get);
                wait=false;
            }else{
                wait=true;
            }
            prev = get;

        }
    }

    public String toString() {
        StringBuilder str = new StringBuilder();
        for (point p : points) {
            str.append(p).append("\n");
        }
        return str.toString();
    }

    //help class
    static class point extends MathRunner.point {

        public boolean paint;

        public point(point other) {
            super(other);
            paint = other.paint;
        }

        public point(String code) {
            super(code);
        }

        public point(MathRunner.point other, double direction, double dist,boolean paint) {
            super(other, direction, dist);
            this.paint = paint;
        }
        
       
        
        public point(double x, double y) {
            super(x, y);
            paint = true;
        }

        public point(double x, double y, boolean paint) {
            super(x, y);
            this.paint = paint;
        }

    }
}
