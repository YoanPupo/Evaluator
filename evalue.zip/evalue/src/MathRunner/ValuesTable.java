/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MathRunner;

import evaluator.PostEval;
import evaluator.Termin;
import evaluator.VarTable;
import java.awt.Graphics;
import java.awt.Point;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 *
 * @author CARLOS
 */
public class ValuesTable {

    static double min = -500, max = 500;
    pencil pen;
    Termin[][] code;
    public static final int CARTESIAN_MODE = 0, POLAR_MODE = 1;
    int drawMode = CARTESIAN_MODE;

    public ValuesTable(String expression, String indep, int drawMode) {
        pen = new pencil();
        double x, y;
        int ind = VarTable.indexOf(indep);
        int xi = VarTable.indexOf("x");
        int yi = VarTable.indexOf("y");
        StringTokenizer cutter = new StringTokenizer(expression, "\n");
        code = new Termin[cutter.countTokens()][100];
        for (int i = 0; i < code.length; i++) {
            code[i] = PostEval.toPost(cutter.nextToken());

        }
        for (double i = min; i < max; i += 0.05) {
            VarTable.setValueOf(ind, i);
            try {
                for (Termin[] termins : code) {
                    PostEval.evalue(termins);
                }
                x = VarTable.getValueOf(xi);
                y = VarTable.getValueOf(yi);
                if (drawMode == CARTESIAN_MODE) {
                    pen.moveTo(x, -y, true);
                } else {
                    pen.moveTo(new pencil.point(point.ORIGIN_POINT, x, -y, true));
                }
            } catch (Exception e) {
                pen.moveTo(i, PostEval.INVALID_VALUE, false);
                System.out.println("invalid value "+i);
            }
        }
    }

    public void draw(Graphics gc) {
        pen.draw(gc);
    }

    @Override
    public String toString() {
        return pen.toString();
    }

    public double getZoomLevel() {
        return pen.getZoomLevel();
    }

    void setZoomLevel(double zoomLevel) {
        pen.setZoomLevel(zoomLevel);
    }

    void setDrawMode(int drawMode) {

    }

    double getMin() {
        LinkedList<pencil.point>points=pen.points;
        double min=-points.getFirst().getY();
        for (pencil.point point1 : points) {
            if(-point1.getY()<min)min=-point1.getY();
        }
        return min;
    }

    double getMax() {
    LinkedList<pencil.point>points=pen.points;
        double max=-points.getFirst().getY();
        for (pencil.point point1 : points) {
            if(-point1.getY()>max)max=-point1.getY();
        }
        return max;}

    Termin[][] getCode() {
        return code;
    }

}
