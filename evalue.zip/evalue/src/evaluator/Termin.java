/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluator;

/**
 *
 * @author YULIER
 */
public interface Termin {
    public static final int CONSTANT=0;
    public static final int VAR=1;
    public static final int OPERATOR=2;
    public static final int FUNCTION=3;
    public double getValue();
    public void setValue(double value);
    public  int getType();
}
