/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluator;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author YULIER
 */
public class VarTable {
    static HashMap<String, Integer>varTable=new HashMap<>();
    static double[] vars=new double[100];
    static int curr=-1;
    public static int indexOf(String name){
        if(varTable.containsKey(name)){
            return varTable.get(name);
        }else{
            varTable.put(name, ++curr);
            vars[curr]=0;
            return curr;
        }
    }public static void setValueOf(int var,double value){
        vars[var]=value;
    }public static double getValueOf(int var){
        return vars[var];
    }
}
