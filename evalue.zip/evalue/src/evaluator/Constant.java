/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluator;

/**
 *
 * @author YULIER
 */
public class Constant implements Termin{
    double value;

    public Constant(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    @Override
    public void setValue(double value) {
        this.value=value;
    }

    @Override
    public int getType() {
        return CONSTANT;
    }
     @Override
    public String toString() {
        return "  ["+getValue()+"]";
    }
}
