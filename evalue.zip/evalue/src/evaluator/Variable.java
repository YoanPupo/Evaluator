/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluator;

/**
 *
 * @author YULIER
 */
public class Variable implements Termin{
    int index;
    String name;

    public Variable(String name) {
        
        this.name = name;
        index=VarTable.indexOf(name);
    }
    @Override
    public double getValue() {
       return VarTable.getValueOf(index);
    }

    @Override
    public void setValue(double value) {
       VarTable.setValueOf(index, value);
    }

    @Override
    public int getType() {
      return VAR;
    }
      @Override
    public String toString() {
        return getClass().getName()+"  "+name+" >>  "+getValue();
    }
}
