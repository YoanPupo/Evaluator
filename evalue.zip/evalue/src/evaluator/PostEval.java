/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluator;

import static evaluator.Termin.*;
import java.util.ArrayList;
import java.util.Stack;
import java.util.StringTokenizer;

/**
 *
 * @author YULIER
 */
public class PostEval {

    public static final double INVALID_VALUE = Double.MAX_VALUE;

    public static double evalue(Termin[] expresion) {
        Stack<Termin> opers = new Stack<>();
           for (Termin termin : expresion) {
                switch (termin.getType()) {
                    case CONSTANT:
                    case VAR:
                        opers.push(termin);
                        break;
                    case OPERATOR:
                        opers.push(new Constant(((Operator) termin).applyTo(opers)));
                        break;
                    case FUNCTION:
                        opers.push(new Constant(((Function) termin).applyTo(opers)));
                        break;
                }
            }
            return opers.pop().getValue();
       
    }

    public static Termin[] toPost(String source) {
        Termin[] terms = convert(source);
        DynamicList<Termin> ret = new DynamicList<>();
        Stack<Operator> opers = new Stack<>();

        for (Termin term : terms) {

            if (term.getType() == OPERATOR || term.getType() == FUNCTION) {//operador
                Operator oper = (Operator) term;
                switch (oper.getOper()) {
                    case Operator.OPEN://parentesis apertura : apilar
                        opers.push(oper);
                        break;
                    case Operator.CLOSE://parentesis cierre :desapilar hasta parentesis apertura
                        while (!opers.empty() && opers.peek().getOper() != Operator.OPEN) {
                            ret.add(opers.pop());
                        }
                        if (!opers.empty()) {
                            opers.pop();
                        }
                        break;
                    default://operadores
                        while ((!opers.empty()) && opers.peek().isPrefOf((Operator) term)) {

                            ret.add(opers.pop());
                        }
                        opers.push((Operator) term);
                        break;
                }
            } else {                        //operando
                ret.add(term);
            }

        }
        while (!opers.empty()) {
            ret.add(opers.pop());
        }
        //System.out.println("toPost :  " + ret);
        return ret.toArray(new Termin[ret.size()]);
    }
    static String symb = "()+-*/^=!>< ";
    static String EMPTY = "";

    public static Termin[] convert(String source) {

        StringTokenizer tok = new StringTokenizer(source, symb, true);
        DynamicList<Termin> ret = new DynamicList<>();
        int prev = OPERATOR;
        String pre = " ";
        while (tok.hasMoreTokens()) {
            String next = tok.nextToken();
            if (next.trim().isEmpty()) {
                continue;
            }
            if (symb.contains(next)) {
                if (prev == OPERATOR && next.equals("-")) {
                    next = "$";
                }
                if (prev == OPERATOR && next.equals("=")) {
                    next = (pre + "=").trim();
                    ret.set(ret.size() - 1, new Operator(next));
                } else {
                    ret.add(new Operator(next));
                }
                prev = next.equals(")") ? CONSTANT : OPERATOR;
            } else if (isNumber(next)) {
                ret.add(new Constant(Double.parseDouble(next)));
                prev = CONSTANT;
            } else if (Function.defineds.contains(next.trim())) {
                ret.add(new Function(next));
                prev = OPERATOR;
            } else {
                ret.add(new Variable(next));
                prev = CONSTANT;
            }
            pre = next;
        }
        //System.out.println(ret);
        return ret.toArray(new Termin[ret.size()]);
    }

    private static boolean isNumber(String next) {
        return Character.isDigit(next.charAt(0));
    }
}
