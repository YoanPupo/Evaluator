/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluator;

import java.util.Stack;

/**
 *
 * @author YULIER
 */
public class Operator implements Termin {

    public static final int ASSIGN = 0;
    public static final int ADD = 1;
    public static final int SUB = 2;
    public static final int MULT = 3;
    public static final int DIV = 4;
    public static final int EXP = 5;
    public static final int NEG = 6;
    public static final int OPEN = 7;
    public static final int CLOSE = 8;
    public static final int MORE = 9;
    public static final int MIN = 10;
    public static final int EQUAL = 11;
    public static final int DIF = 12;
    public static final int MORE_EQ = 13;
    public static final int MIN_EQ = 14;
    static String[] vars = {"=", "+", "-", "*", "/", "^", "$", "(", ")", ">", "<", "==", "!=", ">=", "<="};
    int type = -1;
    static int[] prefs = {0, 1, 1, 2, 2, 4, 5, -1, -1, 0, 0, 0, 0, 0, 0};

    public Operator(String mark) {

        for (int i = 0; i < vars.length; i++) {
            if (mark.trim().equals(vars[i])) {
                type = i;
                break;
            }
            
        }
        if (type == -1) {
                System.out.println("operador indefinido : " + mark);
            }

    }
    public Operator(){
        type=-1;
    }
    @Override
    public double getValue() {
        return 0;
    }

    public int getOper() {
        return type;
    }

    @Override
    public void setValue(double value) {

    }

    public boolean isPrefOf(Operator other) {
        if (other.getType() == FUNCTION) {
            return false;
        }
        if (type == other.getType()) {
            if (type == EXP || type == ASSIGN) {
                return false;
            } else {
                return true;
            }
        } else {

            return prec() >= other.prec();
        }
    }

    public int prec() {
        return prefs[type];
    }

    @Override
    public int getType() {
        return OPERATOR;
    }

    public double applyTo(Stack<Termin> opers) throws RuntimeException {
        double result = Double.MAX_VALUE, a, b;
        switch (type) {
            case NEG:
                return 0 - opers.pop().getValue();

            case ADD:
                return opers.pop().getValue() + opers.pop().getValue();
            case SUB:
                a = opers.pop().getValue();
                b = opers.pop().getValue();
                return b - a;
            case MULT:
                return opers.pop().getValue() * opers.pop().getValue();
            case DIV:
                a = opers.pop().getValue();
                b = opers.pop().getValue();
                if(a==0)throw  new ArithmeticException();
                return b / a;
            case EXP:
                a = opers.pop().getValue();
                b = opers.pop().getValue();
                return Math.pow(b, a);
            case ASSIGN:
                Termin source = opers.pop();
                Termin target = opers.pop();
                target.setValue(source.getValue());
                return target.getValue();
            case EQUAL:
                a = opers.pop().getValue();
                b = opers.pop().getValue();

                return b == a ? 1 : 0;
            case DIF:
                a = opers.pop().getValue();
                b = opers.pop().getValue();

                return a != b ? 1 : 0;
            case MORE:
                a = opers.pop().getValue();
                b = opers.pop().getValue();

                return b > a ? 1 : 0;
            case MIN:
                a = opers.pop().getValue();
                b = opers.pop().getValue();

                return b < a ? 1 : 0;
            case MORE_EQ:
                a = opers.pop().getValue();
                b = opers.pop().getValue();

                return b >= a ? 1 : 0;
            case MIN_EQ:
                a = opers.pop().getValue();
                b = opers.pop().getValue();

                return b <= a ? 1 : 0;
            default:
                System.err.println("operador indefinido");
                throw new RuntimeException("operador indefinido");
        }
    }

    @Override
    public String toString() {
        return " [ " + vars[type] + "]";
    }

}
