/*
 
 */
package evaluator;


import java.io.Serializable;
import java.util.*;

/**
 *
 * @author CARLOS
 */
public class DynamicList< E> extends AbstractSequentialList<E> implements Serializable {

    protected ListNode start, end;
    int size;

    public DynamicList() {
        start = new Mark(Mark.START);
        end = new Mark(Mark.END);
        start.insertNext(end);
    }

    public DynamicList(E... values) {
        this();
        if (values.length == 0) {
            return;
        }
        for (E value : values) {
            addLast(value);
        }
    }

    @Override
    public void add(int index, E element) {
        if (index == 0) {
            addFirst(element);
        } else if (index == size() - 1) {
            addLast(element);
        } else {
            super.add(index, element);
        }

    }

    public void clear() {

        start = new Mark(Mark.START);
        end = new Mark(Mark.END);
        start.insertNext(end);
        size = 0;
    }

    public static void sort(DynamicList list) {
        Object[] array = new Comparable[list.size()];
        array = list.toArray(array);

        Arrays.sort(array);
        for (int i = 0; i < list.size(); i++) {
            list.set(i, array[i]);
        }
    }

    public static void sort(DynamicList list, Comparator com) {
        Object[] array = new Object[list.size()];
        array = list.toArray(array);
        Arrays.sort(array, com);
        for (int i = 0; i < array.length; i++) {
            list.set(i, array[i]);
        }
    }

    public void addFirst(E value) {
        size++;
        ListNode aux = ListNode.newNode(value);
        start.insertNext(aux);
    }

    /**
     *
     * @param value
     */
    public void addLast(E value) {
        size++;

        ListNode aux = new ListNode(value);
        end.insertPrev(aux);

    }

    public E getLast() {
        if (isEmpty()) {
            return null;
        }

        ListNode fr = end.prev;
        Object ret = fr.value;

        return (E) ret;
    }

    public E getFirst() {
        if (isEmpty()) {
            return null;
        }

        ListNode fr = start.next;
        Object ret = fr.value;

        return (E) ret;

    }

    public E deleteLast() {
        if (isEmpty()) {
            return null;
        }
        size--;
        ListNode fr = end.prev.remove();
        Object ret = fr.value;
        fr.free();

        return (E) ret;
    }

    public E deleteFirst() {
        if (isEmpty()) {
            return null;
        }
        size--;
        ListNode fr = start.next.remove();
        Object ret = fr.value;
        fr.free();

        return (E) ret;

    }

    @Override
    public int indexOf(Object o) {
        int index = -1;
        ListIterator iter = listIterator();
        while (iter.hasNext()) {
            index++;
            if (iter.next().equals(o)) {
                return index;
            }
        }
        return -1;
    }

    @Override
    public boolean add(E element) {
        addLast(element);
        return true;
    }

    public String toString() {
        StringBuilder buff = new StringBuilder();
        ListNode aux = start.next;
        int cont = 0;
        while (aux != end) {
            buff.append(aux.value.toString()).append(" - ");
            if (cont++ > 20) {
                buff.append('\n');
                cont = 0;
            }
            aux = aux.next;
        }
        return buff.toString();
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> iterator() {
        return new DynamicListIterator<>(this);
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        return new DynamicListIterator<>(this, index);
    }

   

    @SuppressWarnings("serial")
    public static class ListNode implements Serializable {

        Object value;
        ListNode next;
        ListNode prev;
        boolean isFree;
        static NodeStack stack = new NodeStack(100);
        static boolean debug = false;

        public ListNode(Object value) {
            this(value, null, null);
        }

        public ListNode(Object value, ListNode prev, ListNode next) {
            this.value = value;

            this.next = next;
            this.prev = prev;
            isFree = false;

        }

        public static ListNode newNode(Object value, ListNode prev, ListNode next) {
            ListNode ret;
            //    if (stack.isEmpty()) {
            ret = new ListNode(value, prev, next);
            /*       if (debug) {
                System.out.println("\t----newNode() return new Node");
                }
                } else {
                ret = stack.pop();
                
                if (debug) {
                System.out.println("\t----newNode() return pop Node");
                }
                }*/
            return ret;

        }

        public static ListNode newNode(Object value) {
            return newNode(value, null, null);
        }

        public void insertNext(ListNode nextNode) {
            if (next != null) {
                next.prev = nextNode;
                nextNode.next = next;
            }
            nextNode.prev = this;
            next = nextNode;

        } //prev this next    -------------   prev prevNode this

        public void insertPrev(ListNode prevNode) {
            prev.next = prevNode;
            prevNode.prev = prev;
            prevNode.next = this;
            prev = prevNode;

        }

        //prev  this next ------------- prev next
        public ListNode remove() {
            if (prev != null) {
                prev.next = next;

            }
            if (next != null) {
                next.prev = prev;

            }
            return this;

        }

        protected void finaliz() throws Throwable {
            if (isFree) {
                return;
            }
            if (debug) {
                System.out.println("\t----finalize() free Node");
            }
            free();
        }

        public void free() {
            if (isFree) {
                return;
            }
            value = null;
            //   stack.push(this);
            if (debug) {
                System.out.println("\t----free() free Node");
            }
        }
    }

    public static class DynamicListIterator<E> implements ListIterator<E> {

        protected DynamicListIterator(DynamicList<E> list, int index) {
            this(list);
            if (index < 0 || index > list.size - 1) {
                throw new IndexOutOfBoundsException("indice invalido : " + index + " size: " + list.size());
            }
            for (int i = 0; i < index; i++) {
                next();
            }

        }

        DynamicList<E> list;
        ListNode curr;

        protected DynamicListIterator(DynamicList<E> list) {
            this.list = list;
            this.curr = list.start;

        }

        @Override
        public boolean hasNext() {
            return curr.next != list.end;
        }

        @Override
        @SuppressWarnings("unchecked")
        public E next() {
            if (hasNext()) {
                try {

                    curr = curr.next;
                    return (E) curr.value;
                } catch (Exception e) {
                    System.out.println(curr.getClass().getName());
                }
            }
            throw new NoSuchElementException();

        }

        @Override
        public void remove() {
            if (curr != null) {
                ListNode target = curr;
                curr = curr.prev;
                target.remove();
                // target.free();
                list.size--;

            }
        }

        @Override
        public boolean hasPrevious() {
            return curr.prev != list.start;

        }

        @Override
        @SuppressWarnings("unchecked")
        public E previous() {
            if (hasPrevious()) {
                System.out.println(curr.getClass().getName());
                curr = curr.prev;
                System.out.println(curr);
                return (E) curr.value;
            } else {
                throw new NoSuchElementException();
            }

        }

        @Override
        public int nextIndex() {
            ListNode aux = list.start;
            int index = 0;
            while (aux != curr) {
                index++;
                aux = aux.next;
            }
            return index + 1;
        }

        @Override
        public int previousIndex() {
            return nextIndex() - 2;
        }

        @Override
        public void set(E e) {
            if (curr != list.start && curr != list.end) {
                curr.value = e;
            }
        }

        @Override
        public void add(E e) {

            curr.insertPrev(ListNode.newNode(e));
            list.size++;

        }
    }

    static class NodeStack {

        static int LIMIT = 3000;//tamaño maximo de seguridad
        ListNode top;
        int size;//tamaño actual

        NodeStack() {
            this(0);
        }

        NodeStack(int startSize) {
            size = 0;
            top = null;
            for (int i = 0; i < startSize; i++) {
                push(new ListNode(null));
            }
        }

        void push(ListNode free) {
            size++;
            if (size > LIMIT) {
                return;
            }
            free.isFree = true;
            if (top == null) {
                top = free;
            } else {
                free.insertNext(top);
                top = free;
            }
        }

        ListNode pop() throws RuntimeException {
            ListNode ret = top;
            top = top.next;
            size--;
            ret.isFree = false;
            return ret;
        }

        boolean isEmpty() {
            return top == null;
        }
    }

    private static class Mark extends ListNode {

        int type;
        public static final int START = 0, END = 1;

        public Mark(int type) {
            super(null);
            this.type = type;
        }

        @Override
        public void free() {
            super.free();
        }

        @Override
        public ListNode remove() {
            throw new UnsupportedOperationException(" ERROR!! eliminacion de cabecera");
        }

        @Override
        public void insertPrev(ListNode prevNode) {
            if (type == END) {
                super.insertPrev(prevNode);
            } else {
                throw new UnsupportedOperationException(" ERROR!! insercion antes de inicio");
            }
        }

        @Override
        public void insertNext(ListNode nextNode) {
            if (type == START) {
                super.insertNext(nextNode);
            } else {
                throw new UnsupportedOperationException(" ERROR!! insercion despues de fin");
            }
        }
    }
}
