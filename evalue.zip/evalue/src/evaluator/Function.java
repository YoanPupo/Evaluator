/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluator;

import java.util.List;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author YULIER
 */
public class Function extends Operator{
    String mark;
    public static final String INPUT="load";
    public static final String OUTPUT="print";
    public static final String SIN="sin";
    public static final String COS="cos";
    public static final String TAN="tan";
    public static final String COT="cot";
    public static final String SQRT="sqrt";
    public static final String FACT="fact";
    public static List<String> defineds=new DynamicList<>(INPUT,OUTPUT,SIN,COS,TAN,COT,SQRT,FACT);
    Scanner scan=new Scanner(System.in);
    public Function(String mark) {
        super();
        this.mark=mark;
    }

    @Override
    public int getType() {
        return FUNCTION;
    }
    
    @Override
    public double applyTo(Stack<Termin> opers) throws RuntimeException {
        if(mark.equals(INPUT)){
            System.out.print(" >>  ");
            return scan.nextDouble();
        }else if(mark.equals(OUTPUT)){
            
            System.out.println(opers.peek().getValue());
            return opers.pop().getValue();
        }else if(mark.equals(SIN)){
            return Math.sin(opers.pop().getValue());
        }else if(mark.equals(COS)){
             return Math.cos(opers.pop().getValue());
        }else if(mark.equals(TAN)){
             return Math.tan(opers.pop().getValue());
        }else if(mark.equals(COT)){
             return 1/Math.sin(opers.pop().getValue());
        }else if(mark.equals(SQRT)){
             return Math.sqrt(opers.pop().getValue());
        }else if(mark.equals(FACT)){
             return facorial(opers.pop().getValue());
        }else throw new RuntimeException("funcion indefinida : "+mark);
       
    }

    @Override
    public boolean isPrefOf(Operator other) {
        return true;
    }

    @Override
    public String toString() {
        return "Function{"  + mark + '}';
    }
    public double facorial(double num){
        long cont=(long) num;
        double ret=1;
        while(cont>0){
            ret*=cont;
            cont--;
        }
        return ret;
    }
    
}
